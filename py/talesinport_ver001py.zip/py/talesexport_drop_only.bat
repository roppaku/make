@echo off
setlocal
cd /d "%~dp0"

if "%~1"=="" goto NO_INPUT

set "INPUT_TXT=%~1"
set "SCRIPT=%~dp0talesexport_drop_only.py"

if not exist "%SCRIPT%" (
    echo talesexport_drop_only.py was not found.
    echo Place the BAT and PY files in the same folder.
    pause
    exit /b 1
)

set "PY_CMD="
where py >nul 2>nul
if not errorlevel 1 set "PY_CMD=py -3"
if not defined PY_CMD (
    where python >nul 2>nul
    if not errorlevel 1 set "PY_CMD=python"
)

if not defined PY_CMD (
    echo Python 3 was not found.
    echo Install Python 3 and try again.
    pause
    exit /b 1
)

echo Creating Tales ZIP...
call %PY_CMD% "%SCRIPT%" "%INPUT_TXT%" --no-pause
set "EXITCODE=%ERRORLEVEL%"
echo.
if "%EXITCODE%"=="0" (
    echo Done.
) else (
    echo Failed.
)
pause
exit /b %EXITCODE%

:NO_INPUT
echo Drag and drop a TXT file onto this BAT.
echo The ZIP will be created in the same folder as the TXT file.
pause
exit /b 1
