★talesexport_drop_only 0.01
【ソ フ ト名】 talesexport_drop_only
【ファイル名】 talesexport_drop_only.py / talesexport_drop_only.bat
【制 作 者】 Goldness
【動 作 環境】 Windows 10, 11
【開 発 言語】 Python 3
【ライセンス】 任意

【ソフト紹介】
Talesへ取り込みやすいZIPを、小説原稿のTXTファイルから作成するソフトです。
原稿TXTを「talesexport_drop_only.bat」へドラッグ＆ドロップするだけで、同じフォルダにZIPを作成できます。

【使用方法】
このソフトを使うには、Python 3 が必要です。
「talesexport_drop_only.py」と「talesexport_drop_only.bat」を同じフォルダに置いてください。
そのうえで、原稿TXTを「talesexport_drop_only.bat」へドラッグ＆ドロップしてください。
処理が終わると、原稿TXTと同じフォルダにZIPが作成されます。

原稿TXTは、次の形式で記入してください。

【タイトル】
第1話_タイトル
【本文】
本文

【タイトル】
第2話_タイトル
【本文】
本文

必要に応じて、原稿TXTの先頭に次の情報も記入できます。

作品タイトル: 作品名
クリエイター名: 名前
ジャンル: ジャンル名
キャッチコピー: 紹介文
作品紹介: あらすじ
連載状態: 連載中
タグ: タグ1,タグ2,タグ3

【出力内容】
Tales取り込み用のZIPファイルを作成します。
ZIPファイルは原稿TXTと同じフォルダに保存されます。
ファイル名は「タイトル_YYYYMMDD.zip」の形になります。

【補足】
exe版と違い、py+bat版は中身を確認したり、自分用に調整したりしやすい形です。

【制作】
Goldness

【連絡先】
https://note.com/goldness

【注意】
このソフトウェアを使用したことによって生じた不都合・損害について、制作者は責任を負いません。