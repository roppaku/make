#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

import argparse
import re
import sys
import zipfile
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import List, Optional

JST = timezone(timedelta(hours=9))
DEFAULT_THEME_COLOR = "LIME"
DEFAULT_PUBLIC_STATE = "公開中"
DEFAULT_SERIAL_STATUS = "連載中"
DEFAULT_ACCEPT_COMMENTS = True
DEFAULT_ACCEPT_REVIEWS = True


@dataclass
class Episode:
    title: str
    body: str


@dataclass
class WorkMeta:
    title: str = ""
    creator: str = ""
    genre: str = ""
    catchcopy: str = ""
    description: str = ""
    serial_status: str = DEFAULT_SERIAL_STATUS
    theme_color: str = DEFAULT_THEME_COLOR
    tags: List[str] | None = None
    self_rating: str = ""
    accept_comments: bool = DEFAULT_ACCEPT_COMMENTS
    accept_reviews: bool = DEFAULT_ACCEPT_REVIEWS

    def __post_init__(self) -> None:
        if self.tags is None:
            self.tags = []


def now_jst() -> datetime:
    return datetime.now(JST)


def clean_text(text: str) -> str:
    return text.replace("\r\n", "\n").replace("\r", "\n")


def normalize_title_for_path(title: str) -> str:
    value = title.strip() or "untitled"
    value = re.sub(r'[\\/:*?"<>|]', '_', value)
    value = value.replace('\t', ' ')
    value = re.sub(r'\s+', ' ', value).strip()
    return value[:120] if len(value) > 120 else value


def normalize_episode_title(title: str) -> str:
    value = title.strip().replace('\u3000', ' ')
    value = re.sub(r'^(第\s*\d+\s*話)\s+(.+)$', r'\1_\2', value)
    value = re.sub(r'\s*_[\s_]*', '_', value)
    return value.strip()


def count_japanese_chars(text: str) -> int:
    return len(text.replace('\n', ''))


def read_text_file(path: Path) -> str:
    encodings = ['utf-8-sig', 'utf-8', 'cp932']
    last_error: Optional[Exception] = None
    for encoding in encodings:
        try:
            return path.read_text(encoding=encoding)
        except Exception as exc:
            last_error = exc
    raise RuntimeError(f'テキストを読み込めませんでした: {path}\n{last_error}')


def parse_header_meta(prefix_text: str) -> WorkMeta:
    lines = clean_text(prefix_text).split('\n')
    meta = WorkMeta()
    current_key: Optional[str] = None
    buffers: dict[str, List[str]] = {}

    key_map = {
        '作品タイトル': 'title',
        'タイトル': 'title',
        'クリエイター名': 'creator',
        '著者': 'creator',
        '作者': 'creator',
        'ジャンル': 'genre',
        'キャッチコピー': 'catchcopy',
        '作品紹介': 'description',
        'あらすじ': 'description',
        '紹介': 'description',
        '連載状態': 'serial_status',
        'ステータス': 'serial_status',
        'テーマカラー': 'theme_color',
        'タグ設定': 'tags',
        'ハッシュタグ': 'tags',
        'タグ': 'tags',
        'セルフレイティング': 'self_rating',
    }

    def flush_current() -> None:
        nonlocal current_key
        if not current_key:
            return
        attr = key_map[current_key]
        raw = '\n'.join(buffers.get(current_key, [])).strip()
        if attr == 'tags':
            tags: List[str] = []
            if raw:
                for part in re.split(r'[\n,、，]+', raw):
                    part = part.strip()
                    if part:
                        tags.append(part)
            meta.tags = tags
        elif raw:
            setattr(meta, attr, raw)
        current_key = None

    for line in lines:
        stripped = line.strip()
        match = re.match(
            r'^(作品タイトル|タイトル|クリエイター名|著者|作者|ジャンル|キャッチコピー|作品紹介|あらすじ|紹介|連載状態|ステータス|テーマカラー|タグ設定|ハッシュタグ|タグ|セルフレイティング)\s*[:：]\s*(.*)$',
            stripped,
        )
        if match:
            flush_current()
            current_key = match.group(1)
            buffers.setdefault(current_key, [])
            rest = match.group(2)
            if rest:
                buffers[current_key].append(rest)
            continue
        if current_key is not None:
            buffers[current_key].append(line)

    flush_current()
    return meta


def parse_episodes(full_text: str) -> tuple[WorkMeta, List[Episode]]:
    text = clean_text(full_text)
    matches = list(re.finditer(r'(?m)^【タイトル】\s*$', text))
    if not matches:
        raise ValueError('【タイトル】が見つかりません。テンプレートを確認してください。')

    header_text = text[:matches[0].start()]
    meta = parse_header_meta(header_text)
    episodes: List[Episode] = []

    for index, match in enumerate(matches):
        start = match.end()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        block = text[start:end].strip('\n')
        lines = block.split('\n')

        line_index = 0
        while line_index < len(lines) and not lines[line_index].strip():
            line_index += 1
        if line_index >= len(lines):
            continue

        title_line = lines[line_index].strip()
        line_index += 1

        while line_index < len(lines) and not lines[line_index].strip():
            line_index += 1
        if line_index >= len(lines) or lines[line_index].strip() != '【本文】':
            raise ValueError(f'話「{title_line}」で【本文】が見つかりません。')

        line_index += 1
        body_lines = lines[line_index:]
        while body_lines and not body_lines[-1].strip():
            body_lines.pop()

        title = normalize_episode_title(title_line)
        body = '\n'.join(body_lines).strip('\n')
        if not title:
            raise ValueError('空の話タイトルがあります。')
        if not body.strip():
            raise ValueError(f'話「{title}」の本文が空です。')
        episodes.append(Episode(title=title, body=body))

    if not episodes:
        raise ValueError('本文を含む話が見つかりませんでした。')

    if not meta.title:
        first_title = episodes[0].title
        meta.title = re.sub(r'^第\s*\d+\s*話[_ ]*', '', first_title).strip() or 'untitled'

    return meta, episodes


def format_about(meta: WorkMeta, episodes: List[Episode], dt: datetime) -> str:
    timestamp = dt.strftime('%Y-%m-%d %H:%M:%S (+09:00)')
    total_chars = sum(count_japanese_chars(episode.body) for episode in episodes)
    toc = '\n'.join(f'  {index}. {episode.title}' for index, episode in enumerate(episodes, start=1))
    tags_block = '\n'.join(meta.tags or [])
    comments = 'コメントを受け付ける' if meta.accept_comments else 'コメントを受け付けない'
    reviews = 'レビューを受け付ける' if meta.accept_reviews else 'レビューを受け付けない'
    parts = [
        '# タイトル', meta.title, '',
        '# クリエイター名', meta.creator, '',
        '# ジャンル', meta.genre, '',
        '# キャッチコピー', meta.catchcopy, '',
        '# 作品紹介', meta.description, '',
        '# 連載状態', meta.serial_status, '',
        '# テーマカラー', meta.theme_color, '',
        '# タグ設定', tags_block, '',
        '# セルフレイティング', meta.self_rating, '',
        '# 詳細設定', comments, reviews, '',
        '# 最終更新日時', timestamp, '',
        '# 公開日時', timestamp, '',
        '# 文字数', f'{total_chars}文字', '',
        '# 目次', toc,
    ]
    return '\n'.join(parts).rstrip() + '\n'


def format_episode(episode: Episode, dt: datetime) -> str:
    timestamp = dt.strftime('%Y-%m-%d %H:%M:%S (+09:00)')
    char_count = count_japanese_chars(episode.body)
    parts = [
        '# エピソードタイトル', episode.title, '',
        '# 公開状態', DEFAULT_PUBLIC_STATE, '',
        '# 公開日時', timestamp, '',
        '# 文字数', f'{char_count}文字', '',
        '# 本文', episode.body,
    ]
    return '\n'.join(parts).rstrip() + '\n'


def write_zip(output_zip: Path, folder_name: str, about_text: str, episode_texts: List[str]) -> None:
    output_zip.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output_zip, 'w', compression=zipfile.ZIP_DEFLATED) as zip_file:
        zip_file.writestr(f'{folder_name}/about.txt', about_text.encode('utf-8'))
        for index, text in enumerate(episode_texts, start=1):
            zip_file.writestr(f'{folder_name}/{index:04d}.txt', text.encode('utf-8'))


def build_argparser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description='原稿TXTをTalesインポート用ZIPへ変換します。',
        formatter_class=argparse.RawTextHelpFormatter,
    )
    parser.add_argument('input', nargs='?', help='入力TXT。BATへドラッグ＆ドロップで渡す想定です。')
    parser.add_argument('-o', '--output', help='出力ZIP。未指定なら入力TXTと同じフォルダへ自動作成します。')
    parser.add_argument('--title', help='作品タイトルを上書きします。')
    parser.add_argument('--date', help='ZIP名の日付をYYYYMMDDで固定します。')
    parser.add_argument('--no-pause', action='store_true', help='終了時の入力待ちをしません。')
    return parser


def maybe_pause(no_pause: bool) -> None:
    if no_pause:
        return
    try:
        if sys.stdin is not None and sys.stdin.isatty():
            input('\nEnterで終了します...')
    except (EOFError, KeyboardInterrupt):
        pass


def build_output_path(input_path: Path, work_title: str, folder_date: str, output_arg: Optional[str]) -> Path:
    safe_title = normalize_title_for_path(work_title)
    if output_arg:
        return Path(output_arg)
    return input_path.with_name(f'{safe_title}_{folder_date}.zip')


def run(args: argparse.Namespace) -> Path:
    if not args.input:
        raise ValueError('入力TXTが指定されていません。TXTをBATへドラッグ＆ドロップしてください。')

    input_path = Path(args.input)
    if not input_path.is_file():
        raise FileNotFoundError(f'入力TXTが見つかりません: {input_path}')

    full_text = read_text_file(input_path)
    meta, episodes = parse_episodes(full_text)
    if args.title:
        meta.title = args.title.strip()
    if not meta.title.strip():
        meta.title = input_path.stem

    if args.date:
        if not re.fullmatch(r'\d{8}', args.date):
            raise ValueError('--date は YYYYMMDD 形式で指定してください。')
        dt = datetime.strptime(args.date + '120000+0900', '%Y%m%d%H%M%S%z')
        folder_date = args.date
    else:
        dt = now_jst()
        folder_date = dt.strftime('%Y%m%d')

    safe_title = normalize_title_for_path(meta.title)
    folder_name = f'{safe_title}_{folder_date}'
    output_zip = build_output_path(input_path, meta.title, folder_date, args.output)

    about_text = format_about(meta, episodes, dt)
    episode_texts = [format_episode(episode, dt) for episode in episodes]
    write_zip(output_zip, folder_name, about_text, episode_texts)

    print('OK')
    print(f'INPUT : {input_path.resolve()}')
    print(f'OUTPUT: {output_zip.resolve()}')
    print(f'TITLE : {meta.title}')
    print(f'COUNT : {len(episodes)}')
    return output_zip


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_argparser()
    args = parser.parse_args(argv)
    try:
        run(args)
        return 0
    except Exception as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        return 1
    finally:
        maybe_pause(bool(getattr(args, 'no_pause', False)))


if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1:]))
